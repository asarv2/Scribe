### Subject of the issue
Describe your issue here.

### Your environment
* version of kaltura-typescript-client
* version of angular
* which browser and its version

### Steps to reproduce
Tell us how to reproduce this issue.

### Expected behaviour
Tell us what should happen

### Actual behaviour
Tell us what happens instead